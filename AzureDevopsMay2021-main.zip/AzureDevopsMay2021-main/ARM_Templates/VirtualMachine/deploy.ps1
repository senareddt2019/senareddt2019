# Connect-AzAccount -Tenant "ade07194-d2dc-4bd2-a9bd-8c7e00016c2f" -SubscriptionId "eddcd791-869a-41fb-b93d-f1def2ab2bcf"

New-AzResourceGroup -Name "ford-eastus-dev-rg-01" -Location "East US" 

New-AzResourceGroupDeployment -ResourceGroupName "ford-eastus-dev-rg-01" -TemplateFile ./template.json -TemplateParameterFile ./parameters.json -verbose