#Connect-AzAccount

New-AzResourceGroup -Name "VNET-Peering-rg-01" -Location "East us"

New-AzResourceGroupDeployment -ResourcegroupName "VNET-Peering-rg-01" -TemplateFile ./Azuredeploy.json -TemplateParameterFile ./parameters.json -Verbose



